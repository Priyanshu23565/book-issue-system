package com.example.EMPLOYMENT.Repository;

import com.example.EMPLOYMENT.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Integer> {
}
